---
name: Bug report
about: Report a reproducible SDK example issue
---

**SDK version**

**Operating system / compiler**

**Steps to reproduce**

**Expected behavior**

**Actual behavior**

Do not include real credentials, private vehicle mappings, or personal data.
